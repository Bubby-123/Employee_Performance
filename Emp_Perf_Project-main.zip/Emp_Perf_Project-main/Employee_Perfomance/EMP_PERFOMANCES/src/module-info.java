/**
 * 
 */
/**
 * @author iball
 *
 */
module EMP_PERFOMANCES {
	requires java.sql;
}